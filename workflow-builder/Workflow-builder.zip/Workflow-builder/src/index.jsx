* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;
}

body {
  background: #0f172a;
  color: #e5e7eb;
}

button {
  cursor: pointer;
  border: none;
}
