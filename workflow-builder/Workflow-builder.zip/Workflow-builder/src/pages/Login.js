export default function Login({ onLogin }) {
  return (
    <div style={{ color: "white", padding: "40px" }}>
      <h2>Login Page</h2>
      <button onClick={onLogin}>Login</button>
    </div>
  );
}
