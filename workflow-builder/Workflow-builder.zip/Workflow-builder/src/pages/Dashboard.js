export default function Dashboard() {
  return (
    <div style={{ color: "white", padding: "40px" }}>
      <h2>Dashboard</h2>
    </div>
  );
}
