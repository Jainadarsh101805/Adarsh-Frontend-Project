function App() {
  return (
    <div style={{ color: "white", padding: "40px" }}>
      APP IS LOADING
    </div>
  );
}

export default App;
